<x-layouts.app>
    <x-slot name="header">
        <div class="d-flex align-items-center gap-3">
            <h2 class="fw-semibold fs-4 mb-0">مدیریت مشتریان</h2>
            <h3 class="mb-0">
                <a href="{{ route('marketer.customers.create') }}" class="btn btn-sm btn-primary">
                    ایجاد مشتری جدید
                </a>
            </h3>
        </div>
    </x-slot>

    <div class="py-4">
        <div class="container">
            <div class="card shadow-sm rounded-3">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped align-middle text-start">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col" style="width:60px">#</th>
                                    <th scope="col">نام</th>
                                    <th scope="col">ایمیل</th>
                                    <th scope="col">تلفن</th>
                                    <th scope="col">دسته‌بندی</th>
                                    <th scope="col">منبع</th>
                                    <th scope="col" style="width:140px">فاکتور</th>
                                    <th scope="col" style="width:160px">یادداشت‌ها</th>
                                    <th scope="col" style="width:170px">عملیات</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($customers as $customer)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $customer->name }}</td>
                                        <td>{{ $customer->email ?? '-' }}</td>
                                        <td>{{ $customer->phone ?? '-' }}</td>
                                        <td>{{ $customer->category->name }}</td>
                                        <td>{{ $customer->referenceType->name }}</td>
                                        <td>
                                            <a href="{{ route('marketer.invoices.index', ['customer' => $customer->id]) }}"
                                               class="btn btn-sm btn-outline-dark">
                                                مشاهده فاکتورها
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('marketer.customer.notes.index', [$customer->id])}}"
                                               class="btn btn-sm btn-outline-dark">
                                                مشاهده یادداشت‌ها
                                            </a>
                                        </td>
                                        <td class="d-flex gap-2">
                                            <a href="{{ route('marketer.customers.edit', $customer) }}"
                                               class="btn btn-primary">
                                                ویرایش
                                            </a>

                                            <form action="{{ route('marketer.customers.destroy', $customer) }}"
                                                  method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit"
                                                        onclick="return confirm('آیا از حذف {{ $customer->name }} مطمئن هستید؟')"
                                                        class="btn  btn-danger">
                                                    حذف
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="text-center text-muted py-4">
                                            مشتری‌ای یافت نشد.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-3">
                        {{-- صفحه‌بندی Bootstrap 5 --}}
                        {{ $customers->links('pagination::bootstrap-5') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
<html lang="fa" dir="rtl">
