<x-layouts.app>
    <x-slot name="header">
        <div class="flex gap-4" dir="rtl">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                ویرایش محصول: {{ $product->name }}
            </h2>
            <p>
                <a href="{{ route('admin.products.index') }}"> بازگشت</a>
            </p>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white p-6 shadow-sm sm:rounded-lg" dir="rtl">
                <form action="{{ route('admin.products.update', $product) }}" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="mb-4">
                        <label for="name" class="block text-sm font-medium text-gray-700 text-right">نام محصول</label>
                        <input type="text" name="name" id="name" class="w-full border border-gray-300 rounded px-3 py-2 mt-1 text-right" value="{{ old('name', $product->name) }}" required>
                        @error('name') <span class="text-red-500 text-sm block text-right">{{ $message }}</span> @enderror
                    </div>

                    <div class="mb-4">
                        <label for="description" class="block text-sm font-medium text-gray-700 text-right">توضیحات</label>
                        <textarea name="description" id="description" rows="3" class="w-full border border-gray-300 rounded px-3 py-2 mt-1 text-right" dir="rtl">{{ old('description', $product->description) }}</textarea>
                        @error('description') <span class="text-red-500 text-sm block text-right">{{ $message }}</span> @enderror
                    </div>

                    <div class="mb-4">
                        <label for="price" class="block text-sm font-medium text-gray-700 text-right">قیمت (تومان)</label>
                        <input type="number" name="price" id="price" class="w-full border border-gray-300 rounded px-3 py-2 mt-1 text-right" value="{{ old('price', $product->price) }}" required>
                        @error('price') <span class="text-red-500 text-sm block text-right">{{ $message }}</span> @enderror
                    </div>
                    <div class="text-right">
                        <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                            ذخیره تغییرات
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-layouts.app>
