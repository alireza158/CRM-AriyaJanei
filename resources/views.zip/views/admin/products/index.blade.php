<x-layouts.app>
    <x-slot name="header">
        <div class="flex gap-3 items-center" dir="rtl">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                مدیریت محصولات
            </h2>
            <h3>
                <a href="{{ route('admin.products.create') }}" class="text-blue-600 hover:underline">
                    ایجاد محصول جدید
                </a>
            </h3>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6" dir="rtl">
                <table class="min-w-full table-auto border-collapse border border-gray-200 text-right">
                    <thead>
                    <tr>
                        <th class="border border-gray-300 px-4 py-2 text-right">#</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">نام محصول</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">توضیحات</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">قیمت</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($products as $product)
                        <tr>
                            <td class="border border-gray-300 px-4 py-2 text-right">{{ $loop->iteration }}</td>
                            <td class="border border-gray-300 px-4 py-2 text-right">{{ $product->name }}</td>
                            <td class="border border-gray-300 px-4 py-2 text-right">{{ $product->description ?? '-' }}</td>
                            <td class="border border-gray-300 px-4 py-2 text-right">{{ number_format($product->price) }} تومان</td>
                            <td class="border border-gray-300 px-4 py-2 text-right">
                                <a href="{{ route('admin.products.edit', $product) }}" class="text-green-600 hover:underline">ویرایش</a>
                                |
                                <form action="{{ route('admin.products.destroy', $product) }}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" onclick="return confirm('آیا مطمئن هستید؟')" class="text-red-600 hover:underline bg-transparent border-none p-0 m-0">
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center py-4 text-gray-500">محصولی یافت نشد.</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>

                <div class="mt-4">
                    {{ $products->links() }}
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
