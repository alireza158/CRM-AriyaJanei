<x-layouts.app>
    <x-slot name="header">
        <div class="d-flex gap-3 align-items-center">
            <h2 class="fw-semibold fs-4 mb-0">مدیریت بازاریاب‌ها</h2>
            <span class="text-muted">|</span>
            <h3 class="fs-6 mb-0">
                <a href="{{ route('admin.marketers.create') }}" class="text-decoration-none">ایجاد کاربر بازاریاب</a>
            </h3>
        </div>
    </x-slot>

    <div class="py-4">
        <div class="container">
            <div class="card shadow-sm rounded-3">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-striped align-middle text-start">
                            <thead class="table-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">نام</th>
                                    <th scope="col">تلفن</th>
                                    <th scope="col">نقش</th>
                                    <th scope="col">گزارشات</th>
                                    <th scope="col">مشتریان</th>
                                    <th scope="col">عملیات</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($marketers as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->name }}</td>
                                        <td>{{ $item->phone }}</td>
                                        <td>
                                            @foreach($item->getRoleNames() as $role)
                                                <span class="badge rounded-pill bg-primary-subtle text-primary-emphasis fw-semibold me-1">
                                                    @if ($role == "Marketer")
                                                        بازاریاب
                                                    @else
                                                    {{ $role }}
                                                    @endif
                                                </span>
                                            @endforeach
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.reports.index', $item->id) }}" class="btn btn-sm btn-outline-dark">
                                                مشاهده گزارش
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.marketers.customers.index', $item->id) }}" class="btn btn-sm btn-outline-dark">
                                                مشاهده مشتریان
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.marketers.edit', $item->id) }}" class="btn btn-primary  text-decoration-none">ویرایش</a>
                                            <span class="mx-1 text-muted">|</span>
                                            <form action="{{ route('admin.marketers.destroy', $item->id) }}" method="POST" class="btn btn-danger ">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" onclick="return confirm('آیا مطمئن هستید؟')"
                                                        class="  p-0 m-0  text-decoration-none">
                                                    حذف
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    @if($marketers->isEmpty())
                        <div class="alert alert-secondary text-center mb-0">
                            کاربری یافت نشد.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
 <html lang="fa" dir="rtl">
