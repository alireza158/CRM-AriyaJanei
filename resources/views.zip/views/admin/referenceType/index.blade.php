<x-layouts.app>
    <x-slot name="header">
        <div class="flex gap-3 items-center" dir="rtl">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                مدیریت نوع آشنایی (Reference Type)
            </h2>
            <h3>
                <a href="{{ route('admin.referenceType.create') }}" class="hover:font-bold">
                    ایجاد نوع آشنایی جدید
                </a>
            </h3>
        </div>
    </x-slot>

    <div class="py-12" dir="rtl">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6">
                <table class="min-w-full table-auto border-collapse border border-gray-200 text-right">
                    <thead>
                    <tr>
                        <th class="border border-gray-300 px-4 py-2 text-right">#</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">نام نوع آشنایی</th>
                        <th class="border border-gray-300 px-4 py-2 text-right">عملیات</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($referenceTypes as $referenceType)
                        <tr>
                            <td class="border border-gray-300 px-4 py-2 text-right">{{ $loop->iteration }}</td>
                            <td class="border border-gray-300 px-4 py-2 text-right">{{ $referenceType->name }}</td>
                            <td class="border border-gray-300 px-4 py-2 text-right">
                                <a href="{{ route('admin.referenceType.edit', $referenceType) }}" class="text-green-600 hover:underline ml-2">ویرایش</a>
                                |
                                <form action="{{ route('admin.referenceType.destroy', $referenceType) }}" method="POST" class="inline mr-2">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" onclick="return confirm('آیا مطمئن هستید؟')" class="text-red-600 hover:underline bg-transparent border-none p-0 m-0">
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="3" class="text-center py-4 text-gray-500">نوع آشنایی‌ای یافت نشد.</td>
                        </tr>
                    @endforelse
                    </tbody>
                </table>

{{--                <div class="mt-4">--}}
{{--                    {{ $referenceType->links() }}--}}
{{--                </div>--}}
            </div>
        </div>
    </div>
</x-layouts.app>
