<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-2xl text-gray-900 leading-tight">
            داشبورد
        </h2>
    </x-slot>

    <div class="py-12 bg-gray-50">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="mb-8 text-lg text-gray-800">
                خوش آمدی {{ Auth::user()->name }}
            </div>

            {{-- Admin Dashboard --}}
            @hasrole('Admin')
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <x-dashboard-card
                    title="کاربران بازاریاب"
                    route="admin.marketers.index"
                    svg="user-group"
                    color="bg-blue-200" />
                <x-dashboard-card
                    title="کاربران مهمان"
                    route="admin.guests.index"
                    svg="user"
                    color="bg-purple-200" />
                <x-dashboard-card
                    title="محصولات"
                    route="admin.products.index"
                    svg="box"
                    color="bg-green-200" />
                <x-dashboard-card
                    title="دسته‌بندی‌ها"
                    route="admin.categories.index"
                    svg="tag"
                    color="bg-yellow-200" />
                <x-dashboard-card
                    title="نحوه آشنایی"
                    route="admin.referenceType.index"
                    svg="question"
                    color="bg-pink-200" />
            </div>
            @endhasrole

            {{-- Marketer Dashboard --}}
            @hasrole('Marketer')
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <x-dashboard-card
                    title="مشتریان من"
                    route="marketer.customers.index"
                    svg="users"
                    color="bg-teal-200" />
                <x-dashboard-card
                    title="گزارش‌های من"
                    route="marketer.reports.index"
                    svg="file"
                    color="bg-indigo-200" />
            </div>
            @endhasrole

            {{-- Guest Dashboard --}}
            @hasrole('Guest')
            <div class="grid grid-cols-1 gap-8">
                <x-dashboard-card
                    title="گزارش‌های من"
                    route="guest.reports.index"
                    svg="file"
                    color="bg-orange-200" />
            </div>
            @endhasrole
        </div>
    </div>
</x-app-layout>
